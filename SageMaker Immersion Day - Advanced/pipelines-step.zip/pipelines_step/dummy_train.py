import json
import os

if __name__ == "__main__":
    model_output_directory = os.path.join("/opt/ml/model", "model.json")
    with open(model_output_directory, "w") as f:
        json.dump({"rmse": 5.0}, f)
